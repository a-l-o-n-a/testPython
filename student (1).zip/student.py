class Student:
    def __init__(self, string, firstName, lastName, group, getScholarship):
        self.string = string
        self.firstName = firstName
        self.lastName = lastName
        self.group = group
        self.getScholarship = getScholarship
    def __str__(self):
        return self.string + " " + self.firstName + " " + self.lastName + " " + self.group + " " + str(self.getScholarship)
    
    def IsOld(self):
        if self.getScholarship >= 5:
            return 100
        else:
            return 80

class Aspirant:
    def __init__(self, string, firstName, lastName, group, getScholarship, scientificWork):
        self.string = string
        self.firstName = firstName
        self.lastName = lastName
        self.group = group
        self.getScholarship = getScholarship
        self.scientificWork = scientificWork
    def __str__(self):
        return self.string + " " + self.firstName + " " + self.lastName + " " + self.group + " " + str(self.getScholarship) + " " + self.scientificWork
    def IsOld(self):
        if self.getScholarship >= 5:
            return 200
        else:
            return 180

student = Student("-", "firstName", "lastName", "Python11", 5)
aspirant = Aspirant("-", "firstName1", "lastName2", "Python12", 4, "scientificWork")

print(student)
print(aspirant)

print(student.IsOld())
print(aspirant.IsOld())
